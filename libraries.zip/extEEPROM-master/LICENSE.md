# Arduino External EEPROM Library v3 #
http://github.com/JChristensen/extEEPROM
LICENSE file  
Jack Christensen Jul 2014  

![CC BY-SA](http://mirrors.creativecommons.org/presskit/buttons/88x31/png/by-sa.png)
## CC BY-SA ##
"Arduino External EEPROM Library" by Jack Christensen is licensed under [CC BY-SA 4.0](http://creativecommons.org/licenses/by-sa/4.0/).